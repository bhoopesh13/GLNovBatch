package com.gl.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gl.entity.Book;
import com.gl.service.BookService;


// localhost:8080/books
@Controller
@RequestMapping("/books")
public class BookController {

	@Autowired
	private BookService bookService;
	/*
	 * find out the resources URI that we need to support 
	 *     Done :  /books/showFormForAdd    -> display form where we can fill book object data
	 *      /books/showFormForUpdate -> update book object
	 *      /books/delete -> delete book object based on id
	 *   Done :    /books/save	-> save book object into database
	 *   Done :    /books/list  -> display all books data
	 *      
	 *      extract common URL from all the mapping and put on class level
	 */
	
	@GetMapping("/showFormForAdd") // RequestMapping : showFormForAdd, HttpMethod : Get
	public String showFormForAdd(Model theModel) {
		
		//create model attribtue to bind the data
		
		Book theBook = new Book();
		
		theModel.addAttribute("book", theBook);  
		
		return "books/book-form";
	}
	
	@GetMapping("/list")
	public String listBooks(Model theModel) {
		
		
		//get all the books from the database
		List<Book> theBooks = bookService.findAll();
		
		theModel.addAttribute("books", theBooks);  
		
		return "books/list-books";
		
	}
	
	@PostMapping("/save")
	public String saveBook(@ModelAttribute("book") Book theBook) {
		
		//save the book -> 3
		bookService.save(theBook);
				
		// return list of books
		return "redirect:/books/list";
	}
	
	
	//localhost:8080/books/delete?bookId=1
	
	@PostMapping("/delete")
	public String deleteBook(@RequestParam("bookId") int id) {
		
		//delete the books
		bookService.deleteById(id);
		
		return "redirect:/books/list";
	}
	
	
	@PostMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("bookId") int id, Model theModel) {

		// get the book based on id from the server layer
		Book book = bookService.findById(id);
		
		theModel.addAttribute("book", book);
		
		return "books/book-form";

	}
	
}
