package com.gl.service;

import java.util.List;

import com.gl.entity.Book;

public interface BookService {
	
	//view all books
	public List<Book> findAll();
	
	//insert or update
	public void save(Book theBook);
	
	//deleteById
	public void deleteById(int id);

	public Book findById(int id);

}
