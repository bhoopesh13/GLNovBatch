package com.bhoopesh.problem1.main;

import com.bhoopesh.problem1.service.MinimumTime;

public class Driver {

	public static void main(String args[]) {
		
		//1. Create the object of service class that is MinimumTime
		
		MinimumTime minimumTime = new MinimumTime();
		
		minimumTime.getData();
		
		minimumTime.findMiminumTime();
		
		System.out.println("\n Minimum time needed to deliver all order is : " +
				minimumTime.seconds);
		
	}
}
