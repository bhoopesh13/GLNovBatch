package com.bhoopesh.problem1.service;

import java.util.Collections;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Scanner;

public class MinimumTime {

	Scanner sc = new Scanner(System.in);
	PriorityQueue<Integer>  queue = new PriorityQueue<>(Collections.reverseOrder());
	public int seconds;

	public void getData() {

		System.out.println("Total number of orders for mango milkshake");
		queue.add(sc.nextInt());

		System.out.println("Total number of orders for orange milkshake");
		queue.add(sc.nextInt());

		System.out.println("Total number of orders for pineapple milkshake");
		queue.add(sc.nextInt());	

	}

	public void findMiminumTime() {

		Iterator<Integer> list = queue.iterator();

		while(!queue.isEmpty()) {

			int val1 = 0, val2 = 0;

			if(list.hasNext())
				val1 = queue.remove();
			if(list.hasNext())
				val2 = queue.remove();

			//if both val1 and val2 is != 0

			if(val1 > 0 && val2 > 0) {
				val1--;
				val2--;
				seconds++;
			}

			if(val1 != 0 && val2 == 0) {
				seconds = seconds + val1;
				break;
			}

		

			if(val1 > 0)
				queue.add(val1);
			if(val2 > 0)
				queue.add(val2);

		}
	}

}
