package com.bhoopesh.problem2.service;

public class Node {

	int data;
	public Node left, right;
	
	public Node(int data) {
		
		this.data = data;
		left = right = null;
	}
}
